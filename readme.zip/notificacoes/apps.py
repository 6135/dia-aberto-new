from django.apps import AppConfig


class NotificacoesConfig(AppConfig):
    name = 'notificacoes'
