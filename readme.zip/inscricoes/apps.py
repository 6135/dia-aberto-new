from django.apps import AppConfig


class InscricoesConfig(AppConfig):
    name = 'inscricoes'
