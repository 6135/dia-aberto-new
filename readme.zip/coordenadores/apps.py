from django.apps import AppConfig


class CoordenadoresConfig(AppConfig):
    name = 'coordenadores'
