from django.apps import AppConfig


class ColaboradoresConfig(AppConfig):
    name = 'colaboradores'
