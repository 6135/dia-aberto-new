from django.apps import AppConfig


class AtividadesConfig(AppConfig):
    name = 'atividades'
