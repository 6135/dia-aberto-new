from django.apps import AppConfig


class UtilizadoresConfig(AppConfig):
    name = 'utilizadores'
