drop database diaAberto;
create database diaAberto;